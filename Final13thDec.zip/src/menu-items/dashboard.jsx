// assets
import { UserOutlined } from '@ant-design/icons';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import DnsOutlinedIcon from '@mui/icons-material/DnsOutlined';
import HomeOutlinedIcon from '@mui/icons-material/HomeOutlined';
import LeaderboardOutlinedIcon from '@mui/icons-material/LeaderboardOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';

// icons
const icons = {
  HomeOutlinedIcon,
  DnsOutlinedIcon,
  LeaderboardOutlinedIcon,
  UserOutlined,
  DescriptionOutlinedIcon,
  LogoutOutlinedIcon
};

const dashboard = {
  id: 'group-dashboard',
  title: 'Main',
  type: 'group',
  children: [
    {
      id: 'products',
      title: 'Products',
      type: 'item',
      url: '/products',
      icon: icons.DnsOutlinedIcon,
      breadcrumbs: false
    },
    {
      id: 'dashboard',
      title: 'Dashboard',
      type: 'item',
      url: '/dashboard',
      icon: icons.HomeOutlinedIcon,
      breadcrumbs: false
    }, 
    {
      id: 'Operations',
      title: 'Operations',
      type: 'collapse',
      icon: icons.LeaderboardOutlinedIcon,
      children: [
        {
          id: 'payInOperations',
          title: 'PayIn',
          type: 'item',
          url: '/payInOperations',
          // icon: icons.NightShelterOutlinedIcon,
          breadcrumbs: false
        },
        {
          id: 'payOutOperations',
          title: 'PayOut',
          type: 'item',
          url: '/payOutOperations',
          // icon: icons.NightShelterOutlinedIcon,
          breadcrumbs: false
        },
      ],
    },
    {
      id: 'accounts',
      title: 'Accounts',
      type: 'item',
      url: '/accounts',
      icon: icons.UserOutlined,
      breadcrumbs: false
    },
    {
      id: 'statements',
      title: 'Statements',
      type: 'item',
      url: '/statements',
      icon: icons.DescriptionOutlinedIcon,
      breadcrumbs: false
    },
    {
      id: 'logout',
      title: 'Logout',
      type: 'item',
      icon: icons.LogoutOutlinedIcon,
      url: '/logout',
      breadcrumbs: false
    },
    // {
    //   id: 'profile',
    //   title: 'Profile',
    //   type: 'item',
    //   url: '/profile',
    //   icon: icons.NightShelterOutlinedIcon,
    //   breadcrumbs: false
    // },
  ]
};

export default dashboard;

// project import
import dashboard from './dashboard';

const menuItems = {
  items: [dashboard]
};

export default menuItems;

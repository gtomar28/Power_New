import { lazy } from 'react';

// project import
import Loadable from 'components/Loadable';
import Dashboard from 'layout/Dashboard';
import NoPageFound from 'pages/NoPageFound';;

const DashboardDefault = Loadable(lazy(() => import('pages/dashboard/index')));
const PayInOperationsDefault = Loadable(lazy(() => import('pages/payInOperations/index')));
const PayOutOperationsDefault = Loadable(lazy(() => import('pages/payOutOperations/index')));
const AccountsDefault = Loadable(lazy(() => import('pages/accounts/index')));
const StatementsDefault = Loadable(lazy(() => import('pages/statements/index')));


// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
  path: '/',
  element: <Dashboard />,
  children: [
    {
      path: '/',
      element: <DashboardDefault />
    },
    {
      path: 'payInOperations',
      element: <PayInOperationsDefault />
    },
    {
      path: 'payOutOperations',
      element: <PayOutOperationsDefault />
    },
    {
      path: 'accounts',
      element: <AccountsDefault />
    },
    {
      path: 'statements',
      element: <StatementsDefault />
    },
    {
      path: '/*',
      element: <NoPageFound />
    }
  ]
};

export default MainRoutes;

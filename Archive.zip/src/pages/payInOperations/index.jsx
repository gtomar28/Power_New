import * as React from 'react';
import { Tab } from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { Box, Grid, Typography } from '@mui/material';
import bellNotification from 'assets/images/bellNotification.svg';
import PayInOperationData from 'components/cards/statistics/PayInOperationData';

export default function PayInOperationsDefault() {
    const [value, setValue] = React.useState('1');

    const rows = [
        { id: '1', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32' },
        { id: '2', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Pending', amountStatusBg: '#FFE6BA', amountStatusColor: '#C47F17' },
        { id: '3', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Pending', amountStatusBg: '#FFE6BA', amountStatusColor: '#C47F17' },
        { id: '4', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Expired', amountStatusBg: '#E0E0E0', amountStatusColor: '#757575' },
        { id: '5', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Declined', amountStatusBg: '#FBCBCB', amountStatusColor: '#D32F2F' },
        { id: '6', recieptNo: 'ASAS878', clientName: 'Elena Shaikh', orderId: 'OP12345', createdOn: '26/01/2024', utrNumber: '47283745920', assigneeUpi: 'Elena@HDFC', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32' },
    ];

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Row 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={6}>
                        <Typography variant="h2">Welcome to PayIn Operations</Typography>
                    </Grid>
                    <Grid item xs={12} lg={6} sx={{ display: 'flex' }}>
                        <img src={bellNotification} alt="bellNotification" />
                    </Grid>
                </Grid>
            </Grid>

            {/* Row 2 */}
            <Grid item xs={12} md={12} lg={12}>
                <Box sx={{ width: '100%', typography: 'body1' }}>
                    <TabContext value={value}>
                        <Box sx={{}}>
                            <TabList
                                onChange={handleChange}
                                aria-label="customized tabs"
                                sx={{
                                    '& .MuiTab-root': {
                                        textTransform: 'none',
                                        px: 2.5,
                                        backgroundColor: '#fff',
                                        borderRadius: '10px',
                                        color: '#ADA7A7',
                                        marginRight: 1,
                                        minWidth: 'fit-content',
                                        transition: 'background-color 0.3s',
                                        '&:hover': {
                                            backgroundColor: '#2C6DB5', // Hover background color
                                            color: '#ffffff', // Hover text color
                                        },
                                        '&:active': {
                                            backgroundColor: '#2C6DB5', // Active background color
                                            color: '#ffffff', // Active text color
                                        }
                                    },
                                    '& .Mui-selected': {
                                        backgroundColor: '#2C6DB5', // Active tab background color
                                        color: '#ffffff !important', // Active tab text color
                                        borderRadius: '10px',
                                    },
                                    '& .MuiTabs-indicator': {
                                        backgroundColor: 'transparent', // Remove the default blue indicator
                                    },
                                }}
                            >
                                <Tab label="All" value="1" />
                                <Tab label="Pending" value="2" />
                                <Tab label="Approved" value="3" />
                                <Tab label="Expired" value="4" />
                                <Tab label="Declined" value="5" />
                            </TabList>
                        </Box>
                        <TabPanel value="1"
                            sx={{
                                p:0, py:2
                            }}>
                            <PayInOperationData data={rows} />
                        </TabPanel>
                        <TabPanel value="2">Pending</TabPanel>
                        <TabPanel value="3">Approved</TabPanel>
                        <TabPanel value="4">Expired</TabPanel>
                        <TabPanel value="5">Declined</TabPanel>
                    </TabContext>
                </Box>
            </Grid>
        </Grid>
    );
}

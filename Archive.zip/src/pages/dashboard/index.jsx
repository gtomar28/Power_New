import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';

import UniqueVisitorCard from './UniqueVisitorCard';
import FirstCardBoxHolder from './FirstCardBoxHolder';

export default function DashboardDefault() {
  return (
    <Grid container rowSpacing={4.5} columnSpacing={2.75}>
      {/* Column 1 */}
      <Grid item xs={12} sx={{ mb: -2.25 }}>
        <Typography variant="h5" sx={{ color: '#828282'}}>Hi Rocky,</Typography>
        <Typography variant="h2">Welcome to RockyBook.com Dashboard</Typography>
      </Grid>
      <Grid item xs={12} md={6} lg={6}>
        <FirstCardBoxHolder/>
      </Grid>

      {/* Column 2 */}
      <Grid item xs={12} md={6} lg={6}>
        <UniqueVisitorCard />
      </Grid>

    </Grid>
  );
}

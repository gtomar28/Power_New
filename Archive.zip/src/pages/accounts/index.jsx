import * as React from 'react';
import { Tab } from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { Box, Grid, Typography } from '@mui/material';
import bellNotification from 'assets/images/bellNotification.svg';
import AccountsData from 'components/cards/statistics/AccountsData';

export default function AccountsDefault() {
    const [value, setValue] = React.useState('1');

    const rows = [
        { id: '1', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active', status: true },
        { id: '2', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Last active 1h ago', status: false },
        { id: '3', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active', status: true },
        { id: '4', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Last active 24h 52m ago', status: false },
        { id: '5', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Last active 2h 52m ago', status: false },
    ];

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Row 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={6}>
                        <Typography variant="h2">Welcome to Accounts</Typography>
                    </Grid>
                    <Grid item xs={12} lg={6} sx={{ display: 'flex' }}>
                        <img src={bellNotification} alt="bellNotification" />
                    </Grid>
                </Grid>
            </Grid>

            {/* Row 2 */}
            <Grid item xs={12} md={12} lg={12}>
                <Box sx={{ width: '100%', typography: 'body1' }}>
                    <TabContext value={value}>
                        <Box sx={{}}>
                            <TabList
                                onChange={handleChange}
                                aria-label="customized tabs"
                                sx={{
                                    '& .MuiTab-root': {
                                        textTransform: 'none',
                                        px: 2.5,
                                        backgroundColor: '#fff',
                                        borderRadius: '10px',
                                        color: '#ADA7A7',
                                        marginRight: 1,
                                        minWidth: 'fit-content',
                                        transition: 'background-color 0.3s',
                                        '&:hover': {
                                            backgroundColor: '#2C6DB5',
                                            color: '#ffffff',
                                        },
                                        '&:active': {
                                            backgroundColor: '#2C6DB5',
                                            color: '#ffffff',
                                        }
                                    },
                                    '& .Mui-selected': {
                                        backgroundColor: '#2C6DB5',
                                        color: '#ffffff !important',
                                        borderRadius: '10px',
                                    },
                                    '& .MuiTabs-indicator': {
                                        backgroundColor: 'transparent',
                                    },
                                }}
                            >
                                <Tab label="All" value="1" />
                                <Tab label="Active" value="2" />
                                <Tab label="InActive" value="3" />
                                <Tab label="Admin" value="4" />
                                <Tab label="SubAdmin" value="5" />
                                <Tab label="Peer" value="6" />
                            </TabList>
                        </Box>
                        <TabPanel value="1"
                            sx={{
                                p:0, py:2
                            }}>
                            <AccountsData data={rows} />
                        </TabPanel>
                        <TabPanel value="2">Active</TabPanel>
                        <TabPanel value="3">InActive</TabPanel>
                        <TabPanel value="4">Admin</TabPanel>
                        <TabPanel value="5">SubAdmin</TabPanel>
                        <TabPanel value="6">Peer</TabPanel>
                    </TabContext>
                </Box>
            </Grid>
        </Grid>
    );
}

import * as React from 'react';
import { Box, Button, Grid, Stack, Typography } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';

export default function PayOutOperationData({ payOutData }) {

    console.log(payOutData)
    return (
        <Box>
            {payOutData.map((row) => (
                <Grid container sx={{ backgroundColor: '#E9F0F8', height: '100%', mb:2 }}>
                    <Grid item xs={12} md={10} sx={{ p: 2.4 }}>
                        <Grid container>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Order ID: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.orderId} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Client Name: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.clientName} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Client UPI: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.clientUPI} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Bank name: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.bankName} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Account no.: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.accountNo} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > IFCS: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.iFCS} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Created on: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.createdOn} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Assigned to: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.assignedTo} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Assignee UPI: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.assigneeUPI} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Approved by: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.approvedBy} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > UTR Code: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.uTRCode} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={12} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > UTR receipt: </Typography>
                                        </Grid>
                                        <Grid item xs={12} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.uTRReceipt} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>
                    </Grid >
                    <Grid item xs={12} md={2} alignContent='center' sx={{ height: '100%' }}>
                        <Grid container sx={{ backgroundColor: '#E9F0F8', height: '100%' }}>
                            <Grid item xs={12} md={10} sx={{ height: '100%' }}>
                                <Grid container sx={{ backgroundColor: '#fff', height: '100%', display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
                                    <Typography variant="h4" sx={{ fontWeight: 900 }}>
                                        {row.amount}
                                    </Typography>
                                    <Button disableRipple sx={{
                                        width: 'fit-content', textTransform: 'none', borderRadius: '20px', px: 3, py: 0.5, fontSize: '14px', fontWeight: 500,
                                        backgroundColor: 'red' || '#fff', color: 'white' || '#000', boxShadow: 'none', border: 'none', outline: 'none',
                                        '&:hover, &:active, &:focus': { backgroundColor: 'red', color: 'white', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                    }}>
                                        Approve
                                    </Button>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} md={2} alignContent='center'>
                                <Button sx={{ minWidth: 'fit-content', '&:hover, &:active, &:focus': { backgroundColor: 'transparent !important', } }}><MoreVertIcon sx={{ width: '1.2rem', color: '#2C6DB5', rotate: '90deg' }} /></Button>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid >
            ))}
        </Box>
    );
}



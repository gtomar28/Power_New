import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import UTRSlip from 'assets/images/UTRSlip.svg';
import { Button, Typography } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';

export default function PayInOperationData({ data }) {

    console.log(data)
    return (
        <TableContainer component={Paper} sx={{ borderRadius: '10px' }}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ py: 2.5 }}>Reciept No.</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Client Name</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Order ID</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Created on</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>UTR Number</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>UTR Slip</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Assignee UPI</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Amount</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {data.map((row) => (
                        <TableRow sx={{ backgroundColor: row?.id % 2 === 0 ? '#fff' : '#F2F6FC' }}>
                            <TableCell sx={{ py: 2 }}>{row?.recieptNo}</TableCell>
                            <TableCell sx={{ py: 2 }}>{row?.clientName}</TableCell>
                            <TableCell sx={{ py: 2, color: '#5C82A3', textAlign: 'center' }}>{row?.orderId}</TableCell>
                            <TableCell sx={{ py: 2, color: '#5C82A3', textAlign: 'center' }}>{row?.createdOn}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}>{row?.utrNumber}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}><img src={UTRSlip} alt={UTRSlip} /></TableCell>
                            <TableCell sx={{ py: 2, color: '#2C6DB5', fontWeight: 600, textAlign: 'center' }}>{row?.assigneeUpi}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}>
                                <Button disableRipple sx={{
                                    textTransform: 'none', borderRadius: '20px', px: 3, py: 0.5, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: row?.amountStatusBg || '#fff', color: row?.amountStatusColor || '#000', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: row?.amountStatusBg, color: row?.amountStatusColor, boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    {row?.amountStatus}
                                </Button>
                                <Typography variant="h4" sx={{ mt:1, fontWeight: 900 }}>
                                    {row?.amount}
                                </Typography>
                            </TableCell>
                            <TableCell sx={{ py: 2, display: 'flex' }}>
                                <Button disableRipple sx={{
                                    textTransform: 'none', borderRadius: '32px', px: 2, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: '#01AE08', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: '#01AE08', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    Approve
                                </Button>
                                <Button disableRipple sx={{
                                    minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 2, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    Decline
                                </Button>
                                <Button sx={{ minWidth: 'fit-content', p: 1, '&:hover, &:active, &:focus': { backgroundColor: 'transparent !important', } }}><MoreVertIcon sx={{ width: '1.2rem', color: '#2C6DB5', rotate: '90deg' }} /></Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}


import * as React from 'react';
import { Button, Tab } from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { Box, Grid, Typography } from '@mui/material';
import bellNotification from 'assets/images/bellNotification.svg';
import PayOutOperationData from 'components/cards/statistics/PayOutOperationsData';
import { OutlinedInput, InputAdornment } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';

export default function PayOutOperationsDefault() {
    const [value, setValue] = React.useState('1');

    const rows = [
        {
            id: '1', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32', userStatus: 'Submitted', details: {
                orderId: 'ASAS878', accountNo: '472837457920', assigneeUPI: 'Suman Lala', clientName: 'Elena Shaikh', iFCS: 'SBIN00774',
                uTRCode: 'UPDOWN2948234', clientUPI: 'OP12345', createdOn: '26/01/2024 - 11:34', approvedBy: '', bankName: 'State Bank Of India',
                assignedTo: 'RB Payout - 26/01/2024', uTRReceipt: true
            }
        },
        {
            id: '2', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32', userStatus: 'Assigned', details: {
                orderId: 'ASAS878', accountNo: '472837457920', assigneeUPI: 'Suman Lala', clientName: 'Elena Shaikh', iFCS: 'SBIN00774',
                uTRCode: 'UPDOWN2948234', clientUPI: 'OP12345', createdOn: '26/01/2024 - 11:34', approvedBy: '', bankName: 'State Bank Of India',
                assignedTo: 'RB Payout - 26/01/2024', uTRReceipt: true
            }
        },
        {
            id: '3', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32', userStatus: 'Assigned', details: {
                orderId: 'ASAS878', accountNo: '472837457920', assigneeUPI: 'Suman Lala', clientName: 'Elena Shaikh', iFCS: 'SBIN00774',
                uTRCode: 'UPDOWN2948234', clientUPI: 'OP12345', createdOn: '26/01/2024 - 11:34', approvedBy: '', bankName: 'State Bank Of India',
                assignedTo: 'RB Payout - 26/01/2024', uTRReceipt: true
            }
        },
        {
            id: '4', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32', userStatus: 'Approved', details: {
                orderId: 'ASAS878', accountNo: '472837457920', assigneeUPI: 'Suman Lala', clientName: 'Elena Shaikh', iFCS: 'SBIN00774',
                uTRCode: 'UPDOWN2948234', clientUPI: 'OP12345', createdOn: '26/01/2024 - 11:34', approvedBy: '', bankName: 'State Bank Of India',
                assignedTo: 'RB Payout - 26/01/2024', uTRReceipt: true
            }
        },
        {
            id: '5', amount: '3000 INR', amountStatus: 'Approved', amountStatusBg: '#C8F7C5', amountStatusColor: '#2E7D32', userStatus: 'Submitted', details: {
                orderId: 'ASAS878', accountNo: '472837457920', assigneeUPI: 'Suman Lala', clientName: 'Elena Shaikh', iFCS: 'SBIN00774',
                uTRCode: 'UPDOWN2948234', clientUPI: 'OP12345', createdOn: '26/01/2024 - 11:34', approvedBy: '', bankName: 'State Bank Of India',
                assignedTo: 'RB Payout - 26/01/2024', uTRReceipt: true
            }
        },
    ];

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Row 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={7} alignSelf='center'>
                        <Typography variant="h2">Welcome to PayOut Operations</Typography>
                    </Grid>
                    <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
                        <img src={bellNotification} alt="bellNotification" />
                        <OutlinedInput
                            placeholder="Search"
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: '#3B82F6' }} />
                                </InputAdornment>
                            }
                            sx={{
                                ml: 2,
                                width: '100%',
                                backgroundColor: '#fff',
                                borderRadius: '24px',
                                padding: '6px 16px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&.Mui-focused': {
                                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                },
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>

            {/* Row 2 */}
            <Grid item xs={12} md={12} lg={12}>
                <Box sx={{ width: '100%', typography: 'body1' }}>
                    <TabContext value={value}>
                        <Box sx={{}}>
                            <Grid container >
                                <Grid xs={12} md={6}>
                                    <TabList
                                        onChange={handleChange}
                                        aria-label="customized tabs"
                                        sx={{
                                            '& .MuiTab-root': {
                                                textTransform: 'none',
                                                px: 2.5,
                                                backgroundColor: '#fff',
                                                borderRadius: '10px',
                                                color: '#ADA7A7',
                                                marginRight: 1,
                                                minWidth: 'fit-content',
                                                transition: 'background-color 0.3s',
                                                '&:hover': {
                                                    backgroundColor: '#2C6DB5',
                                                    color: '#ffffff',
                                                },
                                                '&:active': {
                                                    backgroundColor: '#2C6DB5',
                                                    color: '#ffffff',
                                                }
                                            },
                                            '& .Mui-selected': {
                                                backgroundColor: '#2C6DB5',
                                                color: '#ffffff !important',
                                                borderRadius: '10px',
                                            },
                                            '& .MuiTabs-indicator': {
                                                backgroundColor: 'transparent',
                                            },
                                        }}
                                    >
                                        <Tab label="All" value="1" />
                                        <Tab label="Pending" value="2" />
                                        <Tab label="Approved" value="3" />
                                        <Tab label="Declined" value="5" />
                                    </TabList>
                                </Grid>
                                <Grid xs={12} md={6} display='flex' justifyContent='end' alignItems='center'>
                                    <Button href='/createPayOutOperations' disableRipple sx={{
                                        minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 4, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                        backgroundColor: '#DDE7F3', color: '#2C6DB5', boxShadow: 'none', border: 'none', outline: 'none',
                                        '&:hover, &:active, &:focus': { backgroundColor: '#DDE7F3', color: '#2C6DB5', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                    }}>
                                        + Create PayOut Order
                                    </Button>
                                </Grid>
                            </Grid>
                        </Box>
                        <TabPanel value="1"
                            sx={{
                                p: 0, py: 2
                            }}>
                            <PayOutOperationData payOutData={rows} />
                        </TabPanel>
                        <TabPanel value="2">Pending</TabPanel>
                        <TabPanel value="3">Approved</TabPanel>
                        <TabPanel value="5">Declined</TabPanel>
                    </TabContext>
                </Box>
            </Grid>
        </Grid>
    );
}

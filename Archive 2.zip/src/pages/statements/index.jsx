import * as React from 'react';
import { Tab } from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import bellNotification from 'assets/images/bellNotification.svg';
import { OutlinedInput, InputAdornment } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import StatementsData from 'components/cards/statistics/StatementsData';
import { Box, Button, Dialog, Grid, Typography } from '@mui/material';
import { useDialog } from 'components/Dialogs/DialogProvider';

export default function AccountsDefault() {
    const { openDialog } = useDialog();

    const [value, setValue] = React.useState('1');
    const [openDeclineModal, setOpenDeclineModal] = React.useState(false);

    const rows = [
        { id: '1', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayIn', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '50' },
        { id: '2', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayOut', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '1000' },
        { id: '3', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayIn', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '100' },
        { id: '4', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayOut', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '70' },
        { id: '5', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayIn', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '30' },
        { id: '6', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayIn', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '500' },
        { id: '7', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayOut', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '1000' },
        { id: '8', orderId: '23923', dateTime: '2024-8-12/ 11:00:42PM', amount: '20000 INR', type: 'PayIn', payInLimit: '70000 INR', payOutLimit: '70000 INR', commission: '100' },
    ];

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };

    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Row 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={7} alignSelf='center'>
                        <Typography variant="h2">Welcome to Statements</Typography>
                    </Grid>
                    <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
                        <img src={bellNotification} alt="bellNotification" />
                        <OutlinedInput
                            placeholder="Search"
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: '#3B82F6' }} />
                                </InputAdornment>
                            }
                            sx={{
                                ml: 2,
                                width: '100%',
                                backgroundColor: '#fff',
                                borderRadius: '24px',
                                padding: '6px 16px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&.Mui-focused': {
                                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                },
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>

            {/* Row 2 */}
            <Grid item xs={12} md={12} lg={12}>
                <Box sx={{ width: '100%', typography: 'body1' }}>
                    <TabContext value={value}>
                        <Box sx={{}}>
                            <Grid container >
                                <Grid xs={12} md={6}>
                                    <TabList
                                        onChange={handleChange}
                                        aria-label="customized tabs"
                                        sx={{
                                            '& .MuiTab-root': {
                                                textTransform: 'none',
                                                px: 2.5,
                                                backgroundColor: '#fff',
                                                borderRadius: '10px',
                                                color: '#ADA7A7',
                                                marginRight: 1,
                                                minWidth: 'fit-content',
                                                transition: 'background-color 0.3s',
                                                '&:hover': {
                                                    backgroundColor: '#2C6DB5',
                                                    color: '#ffffff',
                                                },
                                                '&:active': {
                                                    backgroundColor: '#2C6DB5',
                                                    color: '#ffffff',
                                                }
                                            },
                                            '& .Mui-selected': {
                                                backgroundColor: '#2C6DB5',
                                                color: '#ffffff !important',
                                                borderRadius: '10px',
                                            },
                                            '& .MuiTabs-indicator': {
                                                backgroundColor: 'transparent',
                                            },
                                        }}
                                    >
                                        <Tab label="All" value="1" />
                                        <Tab label="PayIn" value="2" />
                                        <Tab label="Payout" value="3" />
                                    </TabList>
                                </Grid>
                                <Grid xs={12} md={6} display='flex' justifyContent='end' alignItems='center'>
                                    <Button href='/savedReports' disableRipple sx={{
                                        minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 3.5, mx: 0.5, py: 0.9, fontSize: '14px', fontWeight: 500,
                                        backgroundColor: 'none', border: '1px solid #2C6DB5',color: '#2C6DB5', boxShadow: 'none',
                                        '&:hover, &:active, &:focus': { backgroundColor: 'none', border: '1px solid #2C6DB5',color: '#2C6DB5', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                    }}>
                                       Saved Reports
                                    </Button>
                                    <Button onClick={openDialog} disableRipple sx={{
                                        minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 4, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                        backgroundColor: '#DDE7F3', color: '#2C6DB5', boxShadow: 'none', border: 'none', outline: 'none',
                                        '&:hover, &:active, &:focus': { backgroundColor: '#DDE7F3', color: '#2C6DB5', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                    }}>
                                        + Generate Report
                                    </Button>
                                </Grid>
                            </Grid>
                        </Box>
                        <TabPanel value="1"
                            sx={{
                                p: 0, py: 2
                            }}>
                            <StatementsData data={rows} />
                        </TabPanel>
                        <TabPanel value="2">PayIn</TabPanel>
                        <TabPanel value="3">Payout</TabPanel>
                    </TabContext>
                </Box>
            </Grid>
        </Grid>
    );
}


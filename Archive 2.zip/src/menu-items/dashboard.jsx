// assets
import { DashboardOutlined } from '@ant-design/icons';
import NightShelterOutlinedIcon from '@mui/icons-material/NightShelterOutlined';

// icons
const icons = {
  DashboardOutlined,
  NightShelterOutlinedIcon
};

// ==============================|| MENU ITEMS - DASHBOARD ||============================== //

const dashboard = {
  id: 'group-dashboard',
  title: 'Navigation',
  type: 'group',
  children: [
    {
      id: 'dashboard',
      title: 'Dashboard',
      type: 'item',
      url: '/',
      icon: icons.DashboardOutlined,
      breadcrumbs: false
    },
    // {
    //   id: 'users',
    //   title: 'Users',
    //   type: 'item',
    //   url: '/users',
    //   icon: icons.NightShelterOutlinedIcon,
    //   breadcrumbs: false
    // },
    // {
    //   id: 'operations',
    //   title: 'Operations',
    //   type: 'collapse',
    //   icon: icons.NightShelterOutlinedIcon,
    //   children: [
    //     {
    //       id: 'payInOperations',
    //       title: 'PayIn',
    //       type: 'item',
    //       url: '/payInOperations',
    //       icon: icons.NightShelterOutlinedIcon,
    //       breadcrumbs: false
    //     },
    //     {
    //       id: 'payOutOperations',
    //       title: 'PayOut',
    //       type: 'item',
    //       url: '/payOutOperations',
    //       icon: icons.NightShelterOutlinedIcon,
    //       breadcrumbs: false
    //     }
    //   ],
    // },
    
  ]
};

export default dashboard;

import React, { createContext, useContext, useState } from "react";
import CloseIcon from '@mui/icons-material/Close';
import { Dialog, DialogTitle, DialogContent, Button, Typography, IconButton, Grid, OutlinedInput } from "@mui/material";
import LinearProgress from '@mui/material/LinearProgress';

const DialogContext = createContext();

export const useDialog = () => useContext(DialogContext);

export const DialogProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isGenerated, setIsGenerated] = useState(true);

  const openDialog = () => setIsOpen(true);
  const closeDialog = () => setIsOpen(false);
  const [progress, setProgress] = React.useState(0);

  return (
    <DialogContext.Provider value={{ openDialog, closeDialog }}>
      {children}
      <Dialog
        open={isOpen}
        onClose={closeDialog}
        aria-labelledby="customized-dialog-title"
        maxWidth="sm"
        fullWidth
        sx={{
          '& .MuiDialog-paper': {
            borderRadius: '24px',
          },
        }}
      >
        <Grid sx={{ backgroundColor: '#F2F6FC', borderRadius: '24px', p: 3 }}>
          {/* Dialog Title */}
          <DialogTitle sx={{ display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
            <Typography sx={{ p: 0, textAlign: 'center' }}> Generate Report </Typography>
          </DialogTitle>
          <IconButton
            aria-label="close"
            onClick={() => setOpenDeclineModal(false)}
            sx={(theme) => ({
              position: 'absolute',
              right: 15,
              top: 15,
              color: theme.palette.grey[500],
            })}
          >
            <CloseIcon />
          </IconButton>

          {/* Dialog Content */}
          <DialogContent>
            {!isGenerated ?
              <Grid container spacing={2}>
                {/* Report Name */}
                <Grid item xs={12}>
                  <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Report Name</Typography>
                  <OutlinedInput
                    placeholder="Enter report name"
                    sx={{
                      width: '100%',
                      backgroundColor: '#fff',
                      borderRadius: '15px',
                      height: '40px',
                      fontSize: '14px',
                      padding: '0 14px',
                    }}
                  />
                </Grid>

                {/* Type Dropdown */}
                <Grid item xs={12}>
                  <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Type</Typography>
                  <OutlinedInput
                    placeholder="Select type"
                    sx={{
                      width: '100%',
                      backgroundColor: '#fff',
                      borderRadius: '15px',
                      height: '40px',
                      fontSize: '14px',
                      padding: '0 14px',
                    }}
                  />
                </Grid>

                {/* Amount */}
                <Grid item xs={12}>
                  <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Amount</Typography>
                  <OutlinedInput
                    placeholder="Enter amount"
                    sx={{
                      width: '100%',
                      backgroundColor: '#fff',
                      borderRadius: '15px',
                      height: '40px',
                      fontSize: '14px',
                      padding: '0 14px',
                    }}
                  />
                </Grid>

                {/* Accounts Dropdown */}
                <Grid item xs={12}>
                  <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Accounts</Typography>
                  <OutlinedInput
                    placeholder="Select account"
                    sx={{
                      width: '100%',
                      backgroundColor: '#fff',
                      borderRadius: '15px',
                      height: '40px',
                      fontSize: '14px',
                      padding: '0 14px',
                    }}
                  />
                </Grid>

                {/* Date Range */}
                <Grid item xs={12}>
                  <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Date Range</Typography>
                  <Grid container spacing={1}>
                    <Grid item xs={4}>
                      <OutlinedInput
                        placeholder="Start Date"
                        sx={{
                          width: '100%',
                          backgroundColor: '#fff',
                          borderRadius: '15px',
                          height: '40px',
                          fontSize: '14px',
                          padding: '0 14px',
                        }}
                      />
                    </Grid>
                    <Grid item xs={4}>
                      <OutlinedInput
                        placeholder="End Date"
                        sx={{
                          width: '100%',
                          backgroundColor: '#fff',
                          borderRadius: '15px',
                          height: '40px',
                          fontSize: '14px',
                          padding: '0 14px',
                        }}
                      />
                    </Grid>
                    <Grid item xs={4}>
                      <OutlinedInput
                        placeholder="Select Range"
                        sx={{
                          width: '100%',
                          backgroundColor: '#fff',
                          borderRadius: '15px',
                          height: '40px',
                          fontSize: '14px',
                          padding: '0 14px',
                        }}
                      />
                    </Grid>
                    <Grid item xs={12} sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                      <Button onClick={() => setIsGenerated(true)}
                        disableRipple
                        sx={{
                          textTransform: 'none',
                          borderRadius: '32px',
                          px: 5,
                          py: 1,
                          fontSize: '14px',
                          fontWeight: 500,
                          backgroundColor: '#2C6DB5',
                          color: '#fff',
                          '&:hover': { backgroundColor: '#2C6DB5' },
                        }}
                      >
                        Generate
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>

              </Grid>
              :
              <Grid container spacing={2}>
                {/* Report Name */}
                <Grid item xs={12}>
                  <Typography align="center" sx={{ color: '#000', fontWeight: 'bold' }}>Report is in Progress</Typography>
                  <Typography align="center" sx={{ color: '#929292' }}>Your Report is being processed. Please do not refresh or close this page until the process is complete. This may take a few moments.</Typography>
                </Grid>
                <Grid item xs={12}>
                  <LinearProgress variant="determinate" value={progress} sx={{ m: 10 }} />
                </Grid>

                <Grid container>
                  <Grid item xs={3}></Grid>
                  <Grid item xs={6} sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                    <Button disableRipple sx={{
                      minWidth: '100%', textTransform: 'none', borderRadius: '32px', px: 5, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                      backgroundColor: '#808080', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                      '&:hover, &:active, &:focus': { backgroundColor: '#808080', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                    }}>
                      Download Report
                    </Button>
                  </Grid>
                  <Grid item xs={3}></Grid>
                </Grid>
                <Grid container>
                  <Grid item xs={3}></Grid>
                  <Grid item xs={6} sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                    <Button disableRipple sx={{
                      minWidth: '100%', textTransform: 'none', borderRadius: '32px', px: 5, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                      backgroundColor: '#808080', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                      '&:hover, &:active, &:focus': { backgroundColor: '#808080', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                    }}>
                      Cancel
                    </Button>
                  </Grid>
                  <Grid item xs={3}></Grid>
                </Grid>
              </Grid>

            }

          </DialogContent>

        </Grid>
      </Dialog >
    </DialogContext.Provider >
  );
};

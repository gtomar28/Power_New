import PropTypes from 'prop-types';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';

// project import
import MainCard from 'components/MainCard';
import { Box, Button } from '@mui/material';

export default function AdminStats({ title, items }) {
    return (
        <MainCard contentSX={{ p: 2 }}>
            <Typography variant="h6" sx={{ fontWeight: 900, color: '#676767' }}>
                {title}
            </Typography>
            {items && items.length > 0 && (
                <Grid columnSpacing={2} sx={{ display: 'flex' }}>
                    {items.map((item, index) => (
                        <Grid xs={12} md={6} lg={6} sx={{ m: 1, p: 1.5, backgroundColor: '#F2F6FC', border: '1px solid #E5EEF7', borderRadius: '8px' }}>
                            <Typography variant="h6" sx={{ fontWeight: 900, color: '#676767' }}>
                                {item.admin}
                            </Typography>
                            <Box sx={{ py: 1 }}>
                                <Typography variant="caption" sx={{ color: '#676767' }}>
                                    Total PayIn
                                </Typography>
                            </Box>
                            <Grid sx={{ p: 1.2, backgroundColor: '#fff', borderRadius: '8px' }}>
                                <Typography variant="h4" sx={{ color: '#2C6DB5' }}>
                                    {item.payIn}
                                </Typography>
                            </Grid>
                            <Box sx={{ py: 1 }}>
                                <Typography variant="caption" sx={{ color: '#676767' }}>
                                    Total PayOut
                                </Typography>
                            </Box>
                            <Grid sx={{ p: 1.2, backgroundColor: '#fff', borderRadius: '8px' }}>
                                <Typography variant="h4" sx={{ color: '#2C6DB5' }}>
                                    {item.payOut}
                                </Typography>
                            </Grid>

                            <Box sx={{ display: 'flex', justifyContent: 'center', pt: 2 }}>
                                <Button variant='contained' sx={{ backgroundColor: '#2C6DB5', borderRadius: '34px', px: 4 }}>See Details</Button>
                            </Box>
                        </Grid>
                    ))}
                </Grid>
            )}
        </MainCard>
    );
}

AdminStats.propTypes = {
    title: PropTypes.string,
    items: PropTypes.array,
};

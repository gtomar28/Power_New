import bellNotification from 'assets/images/bellNotification.svg';
import { OutlinedInput, InputAdornment, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { Typography, Grid } from '@mui/material';


export default function CreatePayOut() {
    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Column 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={7} alignSelf='center'>
                        <Typography variant="h2">Welcome to Create Orders</Typography>
                    </Grid>
                    <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
                        <img src={bellNotification} alt="bellNotification" />
                        <OutlinedInput
                            placeholder="Search"
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: '#3B82F6' }} />
                                </InputAdornment>
                            }
                            sx={{
                                ml: 2,
                                width: '100%',
                                backgroundColor: '#fff',
                                borderRadius: '24px',
                                padding: '6px 16px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&.Mui-focused': {
                                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                },
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>
            <Grid item xs={12} >
                <Grid container sx={{ backgroundColor: '#fff', borderRadius: '15px', p: 3 }}>
                    <Typography variant="h5">
                        Enter Details to create order
                    </Typography>
                    <Grid container sx={{ backgroundColor: '#F6F8FC', borderRadius: '15px', p: 1, mt: 2 }}>
                        <Grid item xs={12} md={12} >
                            <Grid fullWidth sx={{ m: 2 }}>
                                <Typography sx={{ color: '#929292', fontWeight: 'bold'}}>Amount</Typography>
                                <OutlinedInput variant="outlined" placeholder='Enter Amount' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                            </Grid>
                        </Grid>
                    <Grid container sx={{ p: 1, m: 2 }}>
                        <Grid xs={12} md={3} display='flex' justifyContent='end' alignItems='center'></Grid>
                        <Grid xs={12} md={6} display='flex' justifyContent='center' alignItems='center'>
                                <Button  disableRipple sx={{
                                    minWidth: '100%', textTransform: 'none', borderRadius: '32px', px: 6, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                }}>
                                    Create Order
                                </Button>
                        </Grid>
                        <Grid xs={12} md={3} display='flex' justifyContent='end' alignItems='center'></Grid>
                        <Grid item >
                        </Grid>
                    </Grid>
                    </Grid>
                </Grid>
            </Grid>


        </Grid>
    );
}

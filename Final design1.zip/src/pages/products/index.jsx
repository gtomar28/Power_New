import bellNotification from 'assets/images/bellNotification.svg';
// import UniqueVisitorCard from './UniqueVisitorCard';
// import FirstCardBoxHolder from './FirstCardBoxHolder';
import { OutlinedInput, InputAdornment } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { Typography, Grid } from '@mui/material';
import ProductDataCards from 'components/cards/statistics/ProductDataCards';
import ProductCards from 'components/cards/statistics/ProductCards';


export default function ProductsDefault() {
    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Column 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={7} alignSelf='center'>
                        <Typography variant="h2">Welcome to Products</Typography>
                    </Grid>
                    <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
                        <img src={bellNotification} alt="bellNotification" />
                        <OutlinedInput
                            placeholder="Search"
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: '#3B82F6' }} />
                                </InputAdornment>
                            }
                            sx={{
                                ml: 2,
                                width: '100%',
                                backgroundColor: '#fff',
                                borderRadius: '24px',
                                padding: '6px 16px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&.Mui-focused': {
                                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                },
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>
            <Grid item xs={12} mt={4}>
                <ProductCards/>
            </Grid>

            <Grid item xs={12} mt={4}>
                <ProductDataCards />
            </Grid>

        </Grid>
    );
}

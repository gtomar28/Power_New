import { Grid } from '@mui/material'
import AmountCards from 'components/cards/statistics/AmountCards';
import AnalyticEcommerce from 'components/cards/statistics/AnalyticEcommerce';

import walletSettings from 'assets/images/walletSettings.svg';
import AdminStats from 'components/cards/statistics/AdminStats';
import AdminCount from 'components/cards/statistics/AdminCount';

const FirstCardBoxHolder = () => {

    const adminStatsData = [
        { admin: 'Admin 1', payIn: '30,00,000', payOut: '22,00,000' },
        { admin: 'Admin 2', payIn: '44,00,000', payOut: '31,00,000' },
    ];

    const adminData = [
        { adminName: 'Admin 1', adminDropOptions:['SuperAdmin1', 'SuperAdmin2', 'SuperAdmin3'] },
        { adminName: 'Admin 2', adminDropOptions:['SuperAdmin1', 'SuperAdmin2', 'SuperAdmin3'] },
    ];

    return (
        <Grid container spacing={2} alignItems='center'>
            <Grid item xs={12} sm={6} md={6} lg={6}>
                <AmountCards title="PayIn Amount" count="74,00,000 INR" extra="Available PayIn Limit: 60,0000" image={walletSettings} />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
                <AmountCards title="PayOut Amount" count="53,00,000 INR" extra="Available PayOut Limit: 40,0000" image={walletSettings} />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
                <AnalyticEcommerce title="Total number of PayIn" count="2200" />
            </Grid>
            <Grid item xs={12} sm={6} md={6} lg={6}>
                <AnalyticEcommerce title="Total number of PayOut" count="600" />
            </Grid>
            <Grid item xs={12} sm={12} md={12} lg={12}>
                <AdminCount title="Total Admin" items={adminData} />
            </Grid>
            <Grid item xs={12} sm={12} md={12} lg={12}>
                <AdminStats title="Stats of Admins" items={adminStatsData} />
            </Grid>
        </Grid>
    )
}

export default FirstCardBoxHolder





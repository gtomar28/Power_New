import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import bellNotification from 'assets/images/bellNotification.svg';
import UniqueVisitorCard from './UniqueVisitorCard';
import FirstCardBoxHolder from './FirstCardBoxHolder';
import { OutlinedInput, InputAdornment } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import Notification from 'layout/Dashboard/Header/HeaderContent/Notification';

export default function DashboardDefault() {
  return (
    <Grid container rowSpacing={4.5} columnSpacing={2.75}>
      {/* Column 1 */}
      <Grid item xs={12} sx={{ mb: -2.25 }}>
        <Typography variant="h5" sx={{ color: '#828282' }}>
          Hi Rocky,
        </Typography>
        <Grid container sx={{ display: 'flex' }}>
          <Grid item xs={12} lg={7} alignSelf='center'>
            <Typography variant="h2">Welcome to RockyBook.com Dashboard</Typography>
          </Grid>
          <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
            {/* <img src={bellNotification} alt="bellNotification" /> */}
            <Notification/>
            <OutlinedInput
              placeholder="Search"
              startAdornment={
                <InputAdornment position="start">
                  <SearchIcon style={{ color: '#3B82F6' }} />
                </InputAdornment>
              }
              sx={{
                ml: 2,
                width: '100%',
                backgroundColor: '#fff',
                borderRadius: '24px',
                padding: '6px 16px',
                '& .MuiOutlinedInput-notchedOutline': {
                  border: 'none',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  border: 'none',
                },
                '&.Mui-focused': {
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                },
              }}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12} md={6} lg={6}>
        <FirstCardBoxHolder />
      </Grid>

      {/* Column 2 */}
      <Grid item xs={12} md={6} lg={6}>
        <UniqueVisitorCard />
      </Grid>

    </Grid>
  );
}

import bellNotification from 'assets/images/bellNotification.svg';
import { OutlinedInput, InputAdornment, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { Typography, Grid } from '@mui/material';


export default function CreateUserPage() {
    return (
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
            {/* Column 1 */}
            <Grid item xs={12} sx={{ mb: -2.25 }}>
                <Typography variant="h5" sx={{ color: '#828282' }}>
                    Hi Rocky,
                </Typography>
                <Grid container sx={{ display: 'flex' }}>
                    <Grid item xs={12} lg={7} alignSelf='center'>
                        <Typography variant="h2">Welcome to Create Sub admin</Typography>
                    </Grid>
                    <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
                        <img src={bellNotification} alt="bellNotification" />
                        <OutlinedInput
                            placeholder="Search"
                            startAdornment={
                                <InputAdornment position="start">
                                    <SearchIcon style={{ color: '#3B82F6' }} />
                                </InputAdornment>
                            }
                            sx={{
                                ml: 2,
                                width: '100%',
                                backgroundColor: '#fff',
                                borderRadius: '24px',
                                padding: '6px 16px',
                                '& .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&:hover .MuiOutlinedInput-notchedOutline': {
                                    border: 'none',
                                },
                                '&.Mui-focused': {
                                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                                },
                            }}
                        />
                    </Grid>
                </Grid>
            </Grid>
            <Grid item xs={12} >
                <Grid container sx={{ backgroundColor: '#fff', borderRadius: '15px', px:2 }}>
                    <Grid item xs={12} md={6} sx={{ p: 2 }}>
                        <Grid container rowSpacing={2}>
                            <Grid item xs={12} >
                                <Typography variant="h5">
                                    Personal Details
                                </Typography>
                                <Grid container rowSpacing={1} columnSpacing={1.5} sx={{ backgroundColor: '#F6F8FC', borderRadius: '15px', p: 1, mt: 2 }}>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Name</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Username</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Email ID</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Phone Number</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Select Role</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} >
                                <Typography variant="h5">
                                    Operations Data
                                </Typography>
                                <Grid container rowSpacing={1} columnSpacing={1.5} sx={{ backgroundColor: '#F6F8FC', borderRadius: '15px', p: 1, mt: 2 }}>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Total PayIn Limit</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Total PayOut Limit</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Min. Amount Limit</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Max. Amount Limit</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>PayIn Commission %</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>PayOut Commission %</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                    <Grid item xs={12} md={6} sx={{ p: 2 }}>
                        <Grid container rowSpacing={2}>
                            <Grid item xs={12} >
                                <Typography variant="h5">
                                    Bank Details
                                </Typography>
                                <Grid container rowSpacing={1} columnSpacing={1.5} sx={{ backgroundColor: '#F6F8FC', borderRadius: '15px', p: 1, mt: 2 }}>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>UPI ID</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Bank Name</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={6} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Branch Name</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Account Number</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>IFSC</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Account Holder Name</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} >
                                <Typography variant="h5">
                                    Create Login Credentials
                                </Typography>
                                <Grid container rowSpacing={1} columnSpacing={1.5} sx={{ backgroundColor: '#F6F8FC', borderRadius: '15px', p: 1, mt: 2 }}>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Create Username</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                    <Grid item xs={12} md={12} >
                                        <Grid fullWidth>
                                            <Typography sx={{ color: '#929292', fontWeight: 'bold' }}>Create Password</Typography>
                                            <OutlinedInput variant="outlined" placeholder='' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#fff', border: 'none', borderRadius: '15px', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid container sx={{ p: 1, m: 2 }}>
                        <Grid xs={12} md={4} display='flex' justifyContent='end' alignItems='center'></Grid>
                        <Grid xs={12} md={4} display='flex' justifyContent='center' alignItems='center'>
                            <Button disableRipple sx={{
                                minWidth: '100%', textTransform: 'none', borderRadius: '32px', px: 6, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                '&:hover, &:active, &:focus': { backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                            }}>
                                Publish User
                            </Button>
                        </Grid>
                        <Grid xs={12} md={4} display='flex' justifyContent='end' alignItems='center'></Grid>
                        <Grid item >
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    );
}


import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material'
import bellNotification from 'assets/images/bellNotification.svg';
import UniqueVisitorCard from './UniqueVisitorCard';
import FirstCardBoxHolder from './FirstCardBoxHolder';
import { OutlinedInput, InputAdornment, Button } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import DriveFileRenameOutlineIcon from '@mui/icons-material/DriveFileRenameOutline';

export default function ProfileDefault() {
  return (
    <Grid container rowSpacing={4.5} columnSpacing={2.75}>
      {/* Column 1 */}
      <Grid item xs={12} sx={{ mb: -2.25 }}>
        <Typography variant="h5" sx={{ color: '#828282' }}>
          Profile / Profile
        </Typography>
        <Grid container sx={{ display: 'flex' }}>
          <Grid item xs={12} lg={7} alignSelf='center'>
            <Typography variant="h2">Profile</Typography>
          </Grid>
          <Grid item xs={12} lg={5} sx={{ display: 'flex', alignItems: 'center' }}>
            <img src={bellNotification} alt="bellNotification" />
            <OutlinedInput
              placeholder="Search"
              startAdornment={
                <InputAdornment position="start">
                  <SearchIcon style={{ color: '#3B82F6' }} />
                </InputAdornment>
              }
              sx={{
                ml: 2,
                width: '100%',
                backgroundColor: '#fff',
                borderRadius: '24px',
                padding: '6px 16px',
                '& .MuiOutlinedInput-notchedOutline': {
                  border: 'none',
                },
                '&:hover .MuiOutlinedInput-notchedOutline': {
                  border: 'none',
                },
                '&.Mui-focused': {
                  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                },
              }}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Grid container rowSpacing={4.5} columnSpacing={2.75}>
          <Grid item xs={12} md={6} lg={7}>
            <FirstCardBoxHolder />
          </Grid>

          {/* Column 2 */}
          <Grid item xs={12} md={6} lg={5}>
            <UniqueVisitorCard />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs={12}>
        <Grid container sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h5">Personal Details</Typography>
          <Button variant='outlined' sx={{ border: '1px solid #2C6DB5', borderRadius: '34px', px: 4, color: '#2C6DB5' }}> <DriveFileRenameOutlineIcon/> Update</Button>
        </Grid>
        <TableContainer component={Paper} sx={{ borderRadius: '10px', mt:2, boxShadow: 'none' }}>
          <Table sx={{ minWidth: 650 }} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell sx={{ py: 0.8, color: '#8E8E8E' }}>Name</TableCell>
                <TableCell sx={{ py: 0.8, color: '#8E8E8E' }}>UserName</TableCell>
                <TableCell sx={{ py: 0.8, color: '#8E8E8E' }}>Email Id</TableCell>
                <TableCell sx={{ py: 0.8, color: '#8E8E8E' }}>Phone Number</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              <TableRow >
                <TableCell sx={{ py: 0.8, fontSize: '12px' }}>Rocky</TableCell>
                <TableCell sx={{ py: 0.8, fontSize: '12px' }}>RockySuperAdmin</TableCell>
                <TableCell sx={{ py: 0.8, fontSize: '12px' }}>Rocky@gmail.com</TableCell>
                <TableCell sx={{ py: 0.8, fontSize: '12px' }}>+91-9835263638</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>

    </Grid>
  );
}

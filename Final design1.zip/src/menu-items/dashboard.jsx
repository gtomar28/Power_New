// assets
import { DashboardOutlined } from '@ant-design/icons';
import NightShelterOutlinedIcon from '@mui/icons-material/NightShelterOutlined';

// icons
const icons = {
  DashboardOutlined,
  NightShelterOutlinedIcon
};

const dashboard = {
  id: 'group-dashboard',
  title: 'Main',
  type: 'group',
  children: [
    {
      id: 'products',
      title: 'Products',
      type: 'item',
      url: '/products',
      icon: icons.NightShelterOutlinedIcon,
      breadcrumbs: false
    },
    {
      id: 'dashboard',
      title: 'Dashboard',
      type: 'item',
      url: '/',
      icon: icons.DashboardOutlined,
      breadcrumbs: false
    }, 
    {
      id: 'Operations',
      title: 'Operations',
      type: 'collapse',
      icon: icons.NightShelterOutlinedIcon,
      children: [
        {
          id: 'payInOperations',
          title: 'PayIn',
          type: 'item',
          url: '/payInOperations',
          icon: icons.NightShelterOutlinedIcon,
          breadcrumbs: false
        },
        {
          id: 'payOutOperations',
          title: 'PayOut',
          type: 'item',
          url: '/payOutOperations',
          icon: icons.NightShelterOutlinedIcon,
          breadcrumbs: false
        },
      ],
    },
    {
      id: 'accounts',
      title: 'Accounts',
      type: 'item',
      url: '/accounts',
      icon: icons.NightShelterOutlinedIcon,
      breadcrumbs: false
    },
    {
      id: 'statements',
      title: 'Statements',
      type: 'item',
      url: '/statements',
      icon: icons.NightShelterOutlinedIcon,
      breadcrumbs: false
    },
    {
      id: 'profile',
      title: 'Profile',
      type: 'item',
      url: '/profile',
      icon: icons.NightShelterOutlinedIcon,
      breadcrumbs: false
    },
    
  ]
};

export default dashboard;

import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import UTRSlip from 'assets/images/UTRSlip.svg';
import { Button, Typography } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import PanoramaFishEyeIcon from '@mui/icons-material/PanoramaFishEye';
import TripOriginIcon from '@mui/icons-material/TripOrigin';
import CircleIcon from '@mui/icons-material/Circle';

export default function AccountsData({ data }) {

    console.log(data)
    return (
        <TableContainer component={Paper} sx={{ borderRadius: '10px' }}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ py: 2.5 }}>Name</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Role</TableCell>
                        <TableCell sx={{ py: 2.5 }}>User UPI ID</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Active status</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {data.map((row) => (
                        <TableRow key={row?.id} sx={{ backgroundColor: row?.id % 2 === 0 ? '#fff' : '#F2F6FC' }}>
                            <TableCell sx={{ py: 1.8 }}>{row?.name}</TableCell>
                            <TableCell sx={{ py: 1.8 }}>{row?.role}</TableCell>
                            <TableCell sx={{ py: 1.8 }}>{row?.userUPIId}</TableCell>
                            <TableCell sx={{ py: 1.8 }}>
                                <Typography alignItems='center' sx={{display: 'flex'}}>
                                    {row?.status
                                        ?
                                        <>
                                            <CircleIcon sx={{ mr: 1, fontSize: '1.2rem', color: '#22C55D' }} />
                                            <Typography variant="body1" sx={{ color: '#22C55D' }}>{row?.activeStatus}</Typography>
                                        </>
                                        :
                                        <>
                                            <CircleIcon sx={{ mr: 1, fontSize: '1.2rem', color: '#EF4444' }} />
                                            <Typography variant="body1" sx={{ color: '#EF4444' }}>{row?.activeStatus}</Typography>
                                        </>
                                    }
                                    
                                </Typography>
                            </TableCell>
                            <TableCell sx={{ py: 1.8, display: 'flex', justifyContent: 'space-between' }}>
                                <Button disableRipple sx={{ '&:hover': { backgroundColor: 'transparent' } }}>
                                    {row?.status
                                        ?
                                        <>
                                            <PanoramaFishEyeIcon sx={{ mr: 1, fontSize: '1.2rem', color: '#EF4444' }} />
                                            <Typography variant="body1" sx={{ color: '#EF4444' }}>Mark Inactive</Typography>
                                        </>
                                        :
                                        <>
                                            <TripOriginIcon sx={{ mr: 1, fontSize: '1.2rem', color: '#22C55D' }} />
                                            <Typography variant="body1" sx={{ color: '#22C55D' }}>Mark Active</Typography>
                                        </>
                                    }
                                </Button>
                                <Button sx={{ minWidth: 'fit-content', p: 1, '&:hover, &:active, &:focus': { backgroundColor: 'transparent !important', } }}><MoreVertIcon sx={{ width: '1.2rem', color: '#2C6DB5', rotate: '90deg' }} /></Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}


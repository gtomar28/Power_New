import * as React from 'react';
import { Box, Button, DialogActions, Grid, OutlinedInput } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CloseIcon from '@mui/icons-material/Close';
import { Dialog, DialogContent, DialogTitle, IconButton, Typography } from '@mui/material';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import CircleIcon from '@mui/icons-material/Circle';

export default function PayOutOperationData({ payOutData }) {

    const rows = [
        { id: '1', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active' },
        { id: '2', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active' },
        { id: '3', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active' },
        { id: '4', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active' },
        { id: '5', name: 'KB Payout', role: 'Peer', userUPIId: 'KB@HDFC', activeStatus: 'Active' },
    ];

    const userData = {
        "Order ID": "OP12345",
        "Client Name": "Elena Shaikh",
        "Client UPI": "OP12345",
        "Bank Name": "State Bank Of India",
        "Account No.": "472837457920",
        "IFSC": "SBIN00774",
        "Created On": "26/01/2024",
        "Assignee To": "KB payout - 26/01/2024 - 11:34",
        "Assigned UPI": "Elena@HDFC",
    };

    const [openSubmittedModal, setOpenSubmittedModal] = React.useState(false);
    const [openApproveModal, setOpenApproveModal] = React.useState(false);
    const [userStatus, setUserStatus] = React.useState('');

    console.log(payOutData)


    return (
        <Box>
            {payOutData.map((row) => (
                <Grid container sx={{ backgroundColor: '#E9F0F8', height: '100%', mb: 2 }}>
                    <Grid item xs={12} md={10} sx={{ p: 2.4 }}>
                        <Grid container>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Order ID: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.orderId} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Client Name: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.clientName} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Client UPI: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.clientUPI} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Bank name: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.bankName} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Account no.: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.accountNo} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > IFCS: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.iFCS} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Created on: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.createdOn} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Assigned to: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.assignedTo} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={12} xl={4} xxl={2} rowSpacing={2}>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Assignee UPI: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.assigneeUPI} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > Approved by: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.approvedBy} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > UTR Code: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.uTRCode} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center', py: 0.4 }} >
                                    <Grid container>
                                        <Grid item xs={6} xl={4} xxl={4} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 'bold', }} > UTR receipt: </Typography>
                                        </Grid>
                                        <Grid item xs={6} xl={8} xxl={8} rowSpacing={2}>
                                            <Typography variant="body" sx={{ fontWeight: 400, color: '#666', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }} > {row?.details?.uTRReceipt} </Typography>
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                        </Grid>
                    </Grid >
                    <Grid item xs={12} md={2} alignContent='center' sx={{ height: '100%' }}>
                        <Grid container sx={{ backgroundColor: '#E9F0F8', height: '100%' }}>
                            <Grid item xs={12} md={10} sx={{ height: '100%' }}>
                                <Grid container sx={{ backgroundColor: '#fff', py:6, height: '100%', display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
                                    <Typography variant="h4" sx={{ fontWeight: 900 }}>
                                        {row.amount}
                                    </Typography>
                                    <Button disableRipple onClick={() => { setOpenSubmittedModal(true), setUserStatus(row?.userStatus) }} sx={{
                                        width: 'fit-content', textTransform: 'none', borderRadius: '20px', px: 3, py: 0.5, fontSize: '14px', fontWeight: 500,
                                        backgroundColor: row?.userStatus === 'Submitted' ? '#E6B400' : row?.userStatus === 'Assigned' ? '#2C6DB5' : row?.userStatus === 'Approved' ? '#22C55D' : '#2C6DB51F', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                        '&:hover, &:active, &:focus': { backgroundColor: row?.userStatus === 'Submitted' ? '#E6B400' : row?.userStatus === 'Assigned' ? '#2C6DB5' : row?.userStatus === 'Approved' ? '#22C55D' : '#2C6DB51F', color: 'white', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                    }}>
                                        {row?.userStatus}
                                    </Button>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} md={2} alignContent='center' sx={{ display: { xs: 'flex', md: 'block' }, justifyContent: { xs: 'center', md: 'unset' }, }}>
                                <Button sx={{ minWidth: 'fit-content', '&:hover, &:active, &:focus': { backgroundColor: 'transparent !important', } }}><MoreVertIcon sx={{ width: '1.2rem', color: '#2C6DB5', rotate: '90deg' }} /></Button>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid >
            ))}


            {/* Approve MOdal */}
            <Dialog
                onClose={() => setOpenSubmittedModal(false)}
                aria-labelledby="customized-dialog-title"
                open={openSubmittedModal}
                maxWidth="sm"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '24px 24px 24px 24px',
                    },
                }}
            >
                <DialogTitle sx={{ m: 1.2, mb: 0, p: 2, backgroundColor: '#F2F6FC', borderRadius: '24px 24px 0px 0px', display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
                    <Typography sx={{ textAlign: 'center' }}> Amount </Typography>
                    <Typography variant='h1' sx={{ textAlign: 'center', color: '#EF4444', fontWeight: '700' }}> 5000 INR </Typography>
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenSubmittedModal(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 18,
                        top: 18,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent sx={{ m: 2, mt:0, p: 2, borderTop: '1px solid #EDEDED', display: 'flex', flexDirection: 'column' }}>
                    {userStatus === 'Assigned' &&
                        <TableContainer >
                            <Table sx={{ width: '100%' }} aria-label="simple table">
                                <TableHead>
                                    <TableRow>
                                        <TableCell sx={{ py: 2.5 }}>Name</TableCell>
                                        <TableCell sx={{ py: 2.5 }}>Role</TableCell>
                                        <TableCell sx={{ py: 2.5 }}>User UPI ID</TableCell>
                                        <TableCell sx={{ py: 2.5 }}>Status</TableCell>
                                        <TableCell sx={{ py: 2.5 }}>Action</TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {rows.map((row) => (
                                        <TableRow key={row?.id} sx={{ backgroundColor: row?.id % 2 === 0 ? '#fff' : '#F2F6FC' }}>
                                            <TableCell sx={{ py: 1.8 }}>{row?.name}</TableCell>
                                            <TableCell sx={{ py: 1.8 }}>{row?.role}</TableCell>
                                            <TableCell sx={{ py: 1.8 }}>{row?.userUPIId}</TableCell>
                                            <TableCell sx={{ py: 1.8 }}>
                                                <Typography alignItems='center' sx={{ display: 'flex' }}>
                                                    <CircleIcon sx={{ mr: 1, fontSize: '1.2rem', color: '#22C55D' }} />
                                                    <Typography variant="body1">{row?.activeStatus}</Typography>
                                                </Typography>
                                            </TableCell>
                                            <TableCell sx={{ py: 1.8, display: 'flex', justifyContent: 'space-between' }}>
                                                <Button disableRipple sx={{
                                                    minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 5, mx: 0.5, py: 0.8, fontSize: '14px', fontWeight: 500,
                                                    backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                                    '&:hover, &:active, &:focus': { backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                                }}>
                                                    Assign
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    }
                    {userStatus === 'Submitted' &&
                        <Grid container>
                            <Grid xs={12} md={6} sx={{ borderRight: '1px dashed #ddd', pr:3}}>
                                <Grid
                                    container
                                    spacing={2}
                                    sx={{
                                        borderRadius: '8px',
                                        maxWidth: '400px',
                                        pb: 2,
                                        backgroundColor: '#fff',
                                    }}
                                >
                                    {Object.entries(userData).map(([key, value]) => (
                                        <>
                                            <Grid item xs={5} key={key}>
                                                <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'start' }}>
                                                    {key}
                                                </Typography>
                                            </Grid>
                                            <Grid item xs={7}>
                                                <Typography variant="body2" sx={{ textAlign: 'end' }}>
                                                    {value}
                                                </Typography>
                                            </Grid>
                                        </>
                                    ))}
                                </Grid>
                            </Grid>
                            <Grid xs={12} md={6}>
                                <Grid fullWidth sx={{ m: 2 }}>
                                    <Typography variant='body1'>Enter UTR*</Typography>
                                    <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                    <Typography variant='body1'>Enter UTR*</Typography>
                                    <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                                    <Typography variant='body1'>Remarks*</Typography>
                                    <OutlinedInput variant="outlined" placeholder='Fake deposit' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' } }} />
                                    <Grid sx={{display: 'flex', justifyContent: 'center'}}>
                                        <Button disableRipple sx={{
                                            minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 6, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                            backgroundColor: '#22C55D', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                            '&:hover, &:active, &:focus': { backgroundColor: '#22C55D', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                                        }}>
                                            Approve
                                        </Button>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Grid>
                    }
                </DialogContent>
            </Dialog>
            {/* Approve MOdal */}
            <Dialog
                onClose={() => setOpenApproveModal(false)}
                aria-labelledby="customized-dialog-title"
                open={openApproveModal}
                maxWidth="xs"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '24px 24px 24px 24px',
                    },
                }}
            >
                <DialogTitle sx={{ m: 1.2, mb: 0, p: 2, backgroundColor: '#F2F6FC', borderRadius: '24px 24px 0px 0px', display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
                    <Typography sx={{ textAlign: 'center' }}> Amount </Typography>
                    <Typography variant='h1' sx={{ textAlign: 'center', color: '#EF4444', fontWeight: '700' }}> 5000 INR </Typography>
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenApproveModal(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 18,
                        top: 18,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent sx={{ m: 1.2, mt: 0, mb: 0, p: 0, borderTop: '1px solid #EDEDED', display: 'flex', flexDirection: 'column' }}>
                    {/* <Grid textAlign="center" xs={10} md={10} lg={10} xl={9} sx={{}}>
                        <Typography sx={{ p: 2 }}> All fields are filled—would you like to <Typography sx={{ ml: 2, fontWeight: 800 }}>approve</Typography> the order now? </Typography></Grid> */}
                    <Grid container

                        textAlign="center" // Centers the content horizontally
                        alignItems="center" // Aligns the content vertically (
                        sx={{ mt: 2 }}
                    >
                        <Grid xs={2}
                            md={2}
                            lg={2}
                            xl={2}></Grid>
                        <Grid

                            xs={8}
                            md={8}
                            lg={8}
                            xl={8}
                        >
                            <Typography
                                variant="body1" // Adjust the typography variant for desired font size
                                sx={{
                                    textAlign: 'center', // Center the text
                                    fontSize: { xs: '12px', md: '12px', lg: '14px' }, // Responsive font size
                                    fontWeight: 400, // Normal weight
                                }}
                            >
                                All fields are filled—would you like to{' '}
                                <Typography
                                    component="span"
                                    sx={{
                                        fontWeight: 'bold', // Bold for "approve"
                                    }}
                                >
                                    approve
                                </Typography>{' '}
                                the order now?
                            </Typography>
                        </Grid>
                        <Grid xs={2}
                            md={2}
                            lg={2}
                            xl={2}></Grid>
                    </Grid>
                    <Grid fullWidth sx={{ m: 2 }}>
                        <Typography>Enter UTR*</Typography>
                        <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                        <Typography>Enter UTR*</Typography>
                        <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb: 2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                    </Grid>
                </DialogContent>
                <DialogActions
                    sx={{
                        mb: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center', // Center-align buttons horizontally
                        gap: 2, // Add space between buttons
                    }}
                >
                    <Grid container justifyContent="center" xs={10} md={10} lg={10} xl={9}>
                        <Button
                            disableRipple
                            fullWidth
                            sx={{
                                textTransform: 'none',
                                borderRadius: '32px',
                                py: 1, // Adjust vertical padding
                                fontSize: '14px', // Slightly larger font size for better appearance
                                fontWeight: 'bold',
                                backgroundColor: '#22C55D', // Green button
                                color: '#fff',
                                '&:hover': {
                                    backgroundColor: '#22C55D', // No color change on hover
                                    color: '#fff',
                                },
                            }}
                        >
                            Approve Now
                        </Button>
                    </Grid>
                    <Grid container justifyContent="center" xs={10} md={10} lg={10} xl={9}>
                        <Button
                            disableRipple
                            fullWidth
                            sx={{
                                textTransform: 'none',
                                borderRadius: '32px',
                                py: 1, // Adjust vertical padding
                                fontSize: '14px', // Slightly larger font size for better appearance
                                fontWeight: 'bold',
                                backgroundColor: '#929292', // Gray button
                                color: '#fff',
                                '&:hover': {
                                    backgroundColor: '#929292', // No color change on hover
                                    color: '#fff',
                                },
                            }}
                        >
                            Let the assignee approve
                        </Button>
                    </Grid>
                </DialogActions>


            </Dialog>
        </Box>


    );
}



import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import UTRSlip from 'assets/images/UTRSlip.svg';
import { Button, Dialog, DialogActions, DialogContent, DialogTitle, Grid, IconButton, OutlinedInput, Typography } from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CloseIcon from '@mui/icons-material/Close';

export default function PayInOperationData({ data }) {
    const [openDeclineModal, setOpenDeclineModal] = React.useState(false);
    const [openApproveModal, setOpenApproveModal] = React.useState(false);
    const [openUTRSlip, setOpenUTRSlip] = React.useState(false);
    
    const userData = {
        "Assignee UPI": "Elena@HDFC",
        "Created On": "26/01/2024",
        "Receipt Number": "000085752257",
        "Client Name": "Elena Shaikh",
        "Order ID": "OP12345",
    };

    console.log(data)
    return (
        <TableContainer component={Paper} sx={{ borderRadius: '10px' }}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                    <TableRow>
                        <TableCell sx={{ py: 2.5 }}>Reciept No.</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Client Name</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Order ID</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Created on</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>UTR Number</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>UTR Slip</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Assignee UPI</TableCell>
                        <TableCell sx={{ py: 2.5, textAlign: 'center' }}>Amount</TableCell>
                        <TableCell sx={{ py: 2.5 }}>Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {data.map((row) => (
                        <TableRow sx={{ backgroundColor: row?.id % 2 === 0 ? '#fff' : '#F2F6FC' }}>
                            <TableCell sx={{ py: 2 }}>{row?.recieptNo}</TableCell>
                            <TableCell sx={{ py: 2 }}>{row?.clientName}</TableCell>
                            <TableCell sx={{ py: 2, color: '#5C82A3', textAlign: 'center' }}>{row?.orderId}</TableCell>
                            <TableCell sx={{ py: 2, color: '#5C82A3', textAlign: 'center' }}>{row?.createdOn}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}>{row?.utrNumber}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}><img src={UTRSlip} alt={UTRSlip} onClick={() => setOpenUTRSlip(true)} /></TableCell>
                            <TableCell sx={{ py: 2, color: '#2C6DB5', fontWeight: 600, textAlign: 'center' }}>{row?.assigneeUpi}</TableCell>
                            <TableCell sx={{ py: 2, textAlign: 'center' }}>
                                <Button disableRipple sx={{
                                    textTransform: 'none', borderRadius: '20px', px: 3, py: 0.5, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: row?.amountStatusBg || '#fff', color: row?.amountStatusColor || '#000', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: row?.amountStatusBg, color: row?.amountStatusColor, boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    {row?.amountStatus}
                                </Button>
                                <Typography variant="h4" sx={{ mt: 1, fontWeight: 900 }}>
                                    {row?.amount}
                                </Typography>
                            </TableCell>
                            <TableCell sx={{ py: 2, display: 'flex' }}>
                                <Button disableRipple onClick={() => setOpenApproveModal(true)} sx={{
                                    textTransform: 'none', borderRadius: '32px', px: 2, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: '#01AE08', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: '#01AE08', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    Approve
                                </Button>
                                <Button disableRipple onClick={() => setOpenDeclineModal(true)} sx={{
                                    minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 2, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                                    backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                                    '&:hover, &:active, &:focus': { backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                                }}>
                                    Decline
                                </Button>
                                <Button sx={{ minWidth: 'fit-content', p: 1, '&:hover, &:active, &:focus': { backgroundColor: 'transparent !important', } }}><MoreVertIcon sx={{ width: '1.2rem', color: '#2C6DB5', rotate: '90deg' }} /></Button>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>


            {/* UTR Slip */}
            <Dialog
                onClose={() => setOpenUTRSlip(false)}
                aria-labelledby="customized-dialog-title"
                open={openUTRSlip}
                maxWidth="xs"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '24px 24px 24px 24px',
                    },
                }}
            >
                <DialogTitle sx={{ m: 1.2, mb: 0, p: 2, backgroundColor: '#F2F6FC', borderRadius: '24px 24px 0px 0px', display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
                    <Typography sx={{ textAlign: 'center' }}> Payment Reciept </Typography>
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenUTRSlip(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 18,
                        top: 18,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent sx={{ m: 1.2, mt: 0, mb: 0, p: 0, borderTop: '1px solid #EDEDED', display: 'flex', flexDirection: 'column' }}>
                    <Grid
                        container
                        spacing={2}
                        sx={{
                            borderTop: '1px dashed #ddd',
                            borderBottom: '1px dashed #ddd',
                            borderRadius: '8px',
                            mt: 2, p: 5,
                            backgroundColor: '#F2F6FC',
                        }}
                    >
                    </Grid>
                </DialogContent>
                <DialogActions sx={{ m: 2, display: 'flex', justifyContent: 'center' }}>
                    <Button disableRipple sx={{
                        minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 6, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                        backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                        '&:hover, &:active, &:focus': { backgroundColor: '#2C6DB5', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                    }}>
                        Close
                    </Button>
                </DialogActions>
            </Dialog>

            {/* Approve MOdal */}
            <Dialog
                onClose={() => setOpenApproveModal(false)}
                aria-labelledby="customized-dialog-title"
                open={openApproveModal}
                maxWidth="xs"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '24px 24px 24px 24px',
                    },
                }}
            >
                <DialogTitle sx={{ m: 1.2, mb: 0, p: 2, backgroundColor: '#F2F6FC', borderRadius: '24px 24px 0px 0px', display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
                    <Typography sx={{ textAlign: 'center' }}> Amount </Typography>
                    <Typography variant='h1' sx={{ textAlign: 'center', color: '#EF4444', fontWeight: '700' }}> 5000 INR </Typography>
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenApproveModal(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 18,
                        top: 18,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent sx={{ m: 1.2, mt: 0, mb: 0, p: 0, borderTop: '1px solid #EDEDED', display: 'flex', flexDirection: 'column' }}>
                    {/* <Grid textAlign="center" xs={10} md={10} lg={10} xl={9} sx={{}}>
                        <Typography sx={{ p: 2 }}> All fields are filled—would you like to <Typography sx={{ ml: 2, fontWeight: 800 }}>approve</Typography> the order now? </Typography></Grid> */}
                    <Grid container
                        textAlign="center"
                        alignItems="center"
                        sx={{ mt: 2 }}
                    >
                        <Grid xs={2}
                        md={2}
                        lg={2}
                        xl={2}></Grid>
                    <Grid
                        
                        xs={8}
                        md={8}
                        lg={8}
                        xl={8}
                    >
                        <Typography
                            variant="body1" // Adjust the typography variant for desired font size
                            sx={{
                                textAlign: 'center', // Center the text
                                fontSize: { xs: '12px', md: '12px', lg: '14px' }, // Responsive font size
                                fontWeight: 400, // Normal weight
                            }}
                        >
                            All fields are filled—would you like to{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold', // Bold for "approve"
                                }}
                            >
                                approve
                            </Typography>{' '}
                            the order now?
                        </Typography>
                    </Grid>
                        <Grid xs={2}
                            md={2}
                            lg={2}
                            xl={2}></Grid>
                    </Grid>
                    <Grid fullWidth sx={{ m:2 }}>
                        <Typography>Enter UTR*</Typography>
                        <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb:2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                        <Typography>Enter UTR*</Typography>
                        <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ mb:2, width: '100%', boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' }, '&:hover': { border: 'none' } }} />
                    </Grid>
                </DialogContent>
                <DialogActions
                    sx={{
                        mb: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center', // Center-align buttons horizontally
                        gap: 2, // Add space between buttons
                    }}
                >
                    <Grid container justifyContent="center" xs={10} md={10} lg={10} xl={9}>
                        <Button
                            disableRipple
                            fullWidth
                            sx={{
                                textTransform: 'none',
                                borderRadius: '32px',
                                py: 1, // Adjust vertical padding
                                fontSize: '14px', // Slightly larger font size for better appearance
                                fontWeight: 'bold',
                                backgroundColor: '#22C55D', // Green button
                                color: '#fff',
                                '&:hover': {
                                    backgroundColor: '#22C55D', // No color change on hover
                                    color: '#fff',
                                },
                            }}
                        >
                            Approve Now
                        </Button>
                    </Grid>
                    <Grid container justifyContent="center" xs={10} md={10} lg={10} xl={9}>
                        <Button
                            disableRipple
                            fullWidth
                            sx={{
                                textTransform: 'none',
                                borderRadius: '32px',
                                py: 1, // Adjust vertical padding
                                fontSize: '14px', // Slightly larger font size for better appearance
                                fontWeight: 'bold',
                                backgroundColor: '#929292', // Gray button
                                color: '#fff',
                                '&:hover': {
                                    backgroundColor: '#929292', // No color change on hover
                                    color: '#fff',
                                },
                            }}
                        >
                            Let the assignee approve
                        </Button>
                    </Grid>
                </DialogActions>


            </Dialog>

            {/* Decline MOdal */}
            <Dialog
                onClose={() => setOpenDeclineModal(false)}
                aria-labelledby="customized-dialog-title"
                open={openDeclineModal}
                maxWidth="xs"
                fullWidth
                sx={{
                    '& .MuiDialog-paper': {
                        borderRadius: '24px 24px 24px 24px',
                    },
                }}
            >
                <DialogTitle sx={{ m: 1.2, mb: 0, p: 2, backgroundColor: '#F2F6FC', borderRadius: '24px 24px 0px 0px', display: 'flex', flexDirection: 'column' }} id="customized-dialog-title">
                    <Typography sx={{ textAlign: 'center' }}> Amount </Typography>
                    <Typography variant='h1' sx={{ textAlign: 'center', color: '#EF4444', fontWeight: '700' }}> 5000 INR </Typography>
                    <Button disableRipple sx={{
                        alignSelf: 'center', width: 'fit-content', textTransform: 'none', borderRadius: '20px', px: 3, py: 0.5, fontSize: '14px', fontWeight: 500,
                        backgroundColor: '#FFD8AB', color: '#BE6700', boxShadow: 'none', border: 'none', outline: 'none',
                        '&:hover, &:active, &:focus': { backgroundColor: '#FFD8AB', color: '#BE6700', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none', },
                    }}>
                        Pending
                    </Button>
                </DialogTitle>
                <IconButton
                    aria-label="close"
                    onClick={() => setOpenDeclineModal(false)}
                    sx={(theme) => ({
                        position: 'absolute',
                        right: 18,
                        top: 18,
                        color: theme.palette.grey[500],
                    })}
                >
                    <CloseIcon />
                </IconButton>
                <DialogContent sx={{ m: 1.2, mt: 0, mb: 0, p: 0, borderTop: '1px solid #EDEDED', display: 'flex', flexDirection: 'column' }}>
                    <Typography sx={{ p: 2, display: 'flex', justifyContent: 'center' }}> UTR : <Typography sx={{ ml: 2, fontWeight: 800 }}>98234823498</Typography> </Typography>
                    <Grid
                        container
                        spacing={2}
                        sx={{
                            borderTop: '1px dashed #ddd',
                            borderBottom: '1px dashed #ddd',
                            borderRadius: '8px',
                            maxWidth: '400px',
                            margin: 'auto',
                            pb: 2,
                            backgroundColor: '#fff',
                        }}
                    >
                        {Object.entries(userData).map(([key, value]) => (
                            <>
                                <Grid item xs={6} key={key}>
                                    <Typography variant="body2" color="textSecondary" sx={{ textAlign: 'start' }}>
                                        {key}
                                    </Typography>
                                </Grid>
                                <Grid item xs={6}>
                                    <Typography variant="body2" sx={{ textAlign: 'end' }}>
                                        {value}
                                    </Typography>
                                </Grid>
                            </>
                        ))}
                    </Grid>
                    <OutlinedInput variant="outlined" placeholder='Remarks: Fake deposit' sx={{ m: 2, boxShadow: 'none', backgroundColor: '#F7F7F7', border: 'none', '&.Mui-focused': { boxShadow: 'none', border: 'none' } }} />
                </DialogContent>
                <DialogActions sx={{ mb: 2, display: 'flex', justifyContent: 'center' }}>
                    <Button disableRipple sx={{
                        minWidth: 'fit-content', textTransform: 'none', borderRadius: '32px', px: 5, mx: 0.5, py: 1, fontSize: '14px', fontWeight: 500,
                        backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', border: 'none', outline: 'none',
                        '&:hover, &:active, &:focus': { backgroundColor: '#FF6262', color: '#fff', boxShadow: 'none', }, '&:focus-visible': { outline: 'none', boxShadow: 'none' }, '&.MuiOutlinedInput - notchedOutline': { borderColor: 'transparent', }, '&.Mui-focused .MuiOutlinedInput-notchedOutline': { borderColor: 'transparent', },
                    }}>
                        Decline
                    </Button>
                </DialogActions>
            </Dialog>
        </TableContainer>

    );
}

